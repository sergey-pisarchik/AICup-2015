#ifndef MYCODE
#define MYCODE

#include "Strategy.h"
using namespace model;
using namespace std;
void f(const Car& self, const World& world, const Game& game, Move& move);

#endif // MYCODE

